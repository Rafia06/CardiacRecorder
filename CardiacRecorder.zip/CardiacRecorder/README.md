# CardiacRecorder
A demo of an app running on android platform that can store blood pressure and heart rate data of users.

### <ins> **UI Mockup:** </ins>
<br>
<br>

<img src = "https://raw.githubusercontent.com/fuadhossain0/CardiacRecorder/main/Documents/Images/SS1.png" alt = "Splash Screen" title = "Splash Screen" width = "270" >
<br>
<br>
<table>
 <tr>
   <td><img src = "https://raw.githubusercontent.com/fuadhossain0/CardiacRecorder/main/Documents/Images/SS2.png" alt = "Main Activity" title = "Main Activity" width = "270" ></td>
   <td><img src = "https://raw.githubusercontent.com/fuadhossain0/CardiacRecorder/main/Documents/Images/SS3.png" alt = "Add New Measurement" title = "Add New Measurement" width = "270" ></td>
 </tr>
</table>  
<br>
<br>
<table>
 <tr>
   <td><img src = "https://raw.githubusercontent.com/fuadhossain0/CardiacRecorder/main/Documents/Images/SS4.png" alt = "Details of a Measurement" title = "Details of a Measurement" width = "270" ></td>
   <td><img src = "https://raw.githubusercontent.com/fuadhossain0/CardiacRecorder/main/Documents/Images/SS5_updated.png" alt = "Update a Measurement" title = "Update a Measurement" width = "270" ></td>
 </tr>
</table>
<br><br>

### <ins> **UML Diagram:** </ins>
<br>
<br>

<img src = "https://raw.githubusercontent.com/fuadhossain0/CardiacRecorder/main/Documents/UML_Diagram.png" alt = "Splash Screen" title = "Splash Screen" width = "1000" >
